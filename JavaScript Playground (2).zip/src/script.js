function cleanobject(obj){
    for (let key in obj){
        if (obj(key)=== null || obj(key) === undefined){
            delete obj(key);
        }
    }
    return obj;
}


let user = {
    nam : "ali",
    age : null,
    email : undefined,
    city: "tehran"
};

let cleanuser = cleanobject(user);
console.log(cleanuser);