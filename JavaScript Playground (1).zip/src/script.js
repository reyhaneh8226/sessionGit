for (let number = 3; number <= 5 ; number ++){
  console.log('{number}$ جدول ضرب عدد \n');
    for ( let multi = 1 ; multi <= 10; multi ++){


if (multi ===3){
  continue;
}
let result = number * multi;
console.log ('${number} x ${multi} = ${result}');
  }
}