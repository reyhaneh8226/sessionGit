let order = {
  laptop: {
    price: 1000,
    count: 1,
    model: 'dell xp5 13',
    namme: 'laptop',
  },
  pen: {
    price: 6,
    count: 12,
    model: 'pilot',
    name: 'pen',
  },
};

for (let item in order) {
  order[item].price += 10;
}

let total = 0;
for (let item in order) {
  total += order[item].price * order[item].count;
}

console.log('مبلغ کل :' + total);
